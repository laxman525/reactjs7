import './App.css';
import AllProductsPage from './components/AllProductsPage';

function App() {
  return (
    <div className="App">
     <AllProductsPage/>
    </div>
  );
}

export default App;
