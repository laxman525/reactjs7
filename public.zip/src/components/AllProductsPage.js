import React from 'react';
import ProductList from './ProductsList';

class AllProductPage extends React.Component {
    constructor() {
        super();
        this.state = {
                'productData': [{
                    'Id': 1,
                    'ProductName': 'MOTO G5',
                    'Quantity': '3',
                    'Price': '50,000'
                },
                {
                    'Id': 2,
                    'ProductName': 'APPLE MAC',
                    'Quantity': '2',
                    'Price': '1,50,000'
                },
                {
                    'Id': 3,
                    'ProductName': 'DELL Inspiron',
                    'Quantity': '4',
                    'Price': '1,30,000'
                },
                {
                    'Id': 4,
                    'ProductName': 'HP Laptop',
                    'Quantity': '6',
                    'Price': '2,30,000'
                },
                {
                    'Id': 5,
                    'ProductName': 'ACER Laptop',
                    'Quantity': '6',
                    'Price': '1,23,000'
                }
                ]
        }
    }


    render() {
        const { productData } = this.state;
            return (<div><h1>Product List:</h1>
                <div><ProductList productData={productData} /></div>
            </div>)
    }
}

export default AllProductPage;