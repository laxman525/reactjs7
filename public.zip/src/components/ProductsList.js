import React from 'react';
import Product from './Product';

class ProductsList extends React.Component {
    render() {
        let data = this.props;
        return <h1>
            <table className="products">
                <thead><tr><th>ID</th><th>Product Name</th><th>Quantity</th><th>Price</th></tr></thead>
                <tbody>
                    {data.productData && data.productData.length && data.productData.map((item, index) => {
                        return <Product key={index} id={item.Id} name={item.ProductName} quantity={item.Quantity} price={item.Price} />
                    })
                    }
                </tbody>
            </table>
        </h1>
    }
}

export default ProductsList;