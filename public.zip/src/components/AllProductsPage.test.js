import { shallow, mount } from 'enzyme';
import AllProductPage from './AllProductsPage';
import ProductsList from './ProductsList';
import toJson from 'enzyme-to-json';

describe('AllProductPage Snapshot', () => {
    let wrapper;
    beforeEach(() => {
        wrapper = mount(<AllProductPage />);
        //console.log(toJson(wrapper));
    });
    test('render correctly', () => {
        expect(wrapper).toMatchSnapshot();
    });
})

describe('AllProductPage rendering of elements ', () => {
    let wrapper1;
    beforeEach(() => {
        wrapper1 = shallow(<AllProductPage />);
    });
    test('renders correct heading for Product List', () => {
        let textHeading = wrapper1.find('h1').first();
        expect(textHeading.render().text()).toContain('Product List');
    });
    test('renders one ProductList React Component', () => {
        let compProductList = wrapper1.find(ProductsList);
        expect(compProductList.length).toEqual(1);
    });
})