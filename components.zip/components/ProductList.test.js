import { shallow, mount } from 'enzyme';
import ProductsList from './ProductsList';
import Product from './Product';
import toJson from 'enzyme-to-json';

describe('When Valid Products Array props passed to ProductList Component', () => {
    let wrapper1;
    let props1;
    beforeEach(() => {
        props1 = {
            products: [
                {
                    "id": 1,
                    "name": "Product_1",
                    "quantity": 1,
                    "price": 10
                },
                {
                    "id": 2,
                    "name": "Product_2",
                    "quantity": 2,
                    "price": 20
                }
            ]
        }
        wrapper1 = shallow(<ProductsList productData={props1.products} />);
        //expect(wrapper1).toMatchSnapshot();
      
    });

    test('renders "Product Name" as heading in second coloumn', () => {
        let textHeading = wrapper1.find('thead tr th').at(1);
        expect(textHeading.render().text()).toContain('Product Name');
    });
    test('renders "Price" as heading in fourth coloumn', () => {
        let textHeading = wrapper1.find('thead tr th').at(3);
        expect(textHeading.render().text()).toContain('Price');
    });

    test('passes the 2nd products name as props to second product component', () => {
        expect(wrapper1.instance().props.productData[1].name).toContain('Product_2');
    });
    test('passes the 2nd products price as props to second product component', () => {
        expect(wrapper1.instance().props.productData[1].price).toEqual(20);
    });

})

describe('When Products Array props passed to ProductList Component is null', () => {
    let wrapper2;
    let props;
    beforeEach(() => {
        props = {
            productData: null
        }
        wrapper2 = shallow(<ProductsList productData={props.productData} />);
    });
    test('should not crush and no product component is rendered', () => {
        //expect(wrapper2).toMatchSnapshot();
        expect(wrapper2.find(Product)).toHaveLength(0);
    });
})